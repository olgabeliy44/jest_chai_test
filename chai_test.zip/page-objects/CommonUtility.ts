/**
 * Common usages upon String/Numbers/Regex/Date/Object/restful service call.
 */

'use strict';

import { AppConfig } from './app.config';
import Constants from './Constants';
import { stringMap } from './string-replacement';
//var GPILoggerClient = require('@gpi-logger');
var GPILoggerClient;

var _ = require('lodash');
var moment = require('moment');
var moment;


class CommonUtility {

  constructor() {

  }

  static startsWith(str: string, value) {
    return _.startsWith(str, value);
  }

  static isEmpty(value: any) {
    return _.isEmpty(value);
  }

  static deepClone(obj: any) {
    return _.cloneDeep(obj);
  }

  static inArray(item: any, arr: any) {
    var inArray = false;
    if(_.isArray(arr)){
      inArray = arr.indexOf(item) > -1;
    }
    return inArray;
  }

  static getLogObjectTemplate(){
    return {
      origin: '',
      service : '',
      operation : '',
      request: {},
      response: {},
      timeConsumed : '',
      logUID : '',
      authContext: '',
      errorResponse: '',
      errorInfo: {
        errorCode: '',
        errorMessage: ''
      },
      febSecReqId: '',
      requestUri: ''
    };
  }

  static showErrorLogMessage(params: any){
    var resultCode = params.errorResponse && params.errorResponse.errorCode ? params.errorResponse.errorCode : 'Generic Result Code';
    params.errorInfo.errorMessage = CommonUtility.getLoggingString(CommonUtility.maskData(params.errorInfo.errorMessage), CommonUtility.maskData(params.errorResponse));
    const authenticationContext = params.authContext;
    var genericLogDetails = authenticationContext && authenticationContext.repInfo ? CommonUtility.getLoggingString(Constants.GENERIC_LOG_INFO, AppConfig.APP.APP_ID, authenticationContext.trackingId,authenticationContext.febSecReqId,
      authenticationContext.sessionId,authenticationContext.mid, authenticationContext.repInfo.id, authenticationContext.repInfo.mid,
      authenticationContext.sid, authenticationContext.repInfo.sid,authenticationContext.pointOfEntry, authenticationContext.productVersion || 'DAT_1.0'): '';

    var errorLogDetails = CommonUtility.getLoggingString(Constants.APP_ERROR_LOG, params.origin ? params.origin : Constants.APP_ORIGIN,
      params.errorInfo.errorCode, params.service, params.operation, resultCode, params.errorInfo.errorMessage,genericLogDetails,
      !_.isEmpty(params.logUID) ? params.logUID : CommonUtility.getLogID(), CommonUtility.maskData(params.request), CommonUtility.maskData(params.response), params.requestUri);

    return errorLogDetails;
  }

  static showLogInfoMessage(params: any) {
    var authenticationContext = params.authContext;
    var genericLogDetails = authenticationContext && authenticationContext.repInfo ? CommonUtility.getLoggingString(Constants.GENERIC_LOG_INFO, AppConfig.APP.APP_ID, authenticationContext.trackingId,authenticationContext.febSecReqId,
      authenticationContext.sessionId,authenticationContext.mid, authenticationContext.repInfo.id, authenticationContext.repInfo.mid,
      authenticationContext.sid, authenticationContext.repInfo.sid,authenticationContext.pointOfEntry, authenticationContext.productVersion || 'DAT_1.0'): '';

    var logInfo = CommonUtility.getLoggingString(Constants.APP_INFO_LOG, params.origin ? params.origin : Constants.APP_ORIGIN, params.service, params.operation, genericLogDetails,
      !_.isEmpty(params.logUID) ? params.logUID : CommonUtility.getLogID(), CommonUtility.maskData(params.request), CommonUtility.maskData(params.response), params.requestUri);

    return logInfo;
  }

  static showPerfLogMsg(params: any){
    const authenticationContext = params.authContext;
    var genericLogDetails = authenticationContext && authenticationContext.repInfo ? CommonUtility.getLoggingString(Constants.GENERIC_LOG_INFO, AppConfig.APP.APP_ID, authenticationContext.trackingId,authenticationContext.febSecReqId,
      authenticationContext.sessionId,authenticationContext.mid,authenticationContext.repInfo.id, authenticationContext.repInfo.mid,
      authenticationContext.sid, authenticationContext.repInfo.sid,authenticationContext.pointOfEntry, authenticationContext.productVersion || 'DAT_1.0'): '';

    var logInfo = CommonUtility.getLoggingString(Constants.PERF_LOG, params.origin, params.service, params.operation,
      !_.isEmpty(params.logUID) ? params.logUID : CommonUtility.getLogID(),params.timeConsumed.toString(), genericLogDetails, params.requestUri);

    return logInfo;
  }

  /**
   * Mask the private data
   * @param input
   * @returns {string}
   */
  static maskData(input: any){
    var maskString = typeof input == 'object' ? JSON.stringify(input) : input;
    if(maskString)
    {
      for (var key in stringMap)
      {
        var pattern = new RegExp(key,"gi");
        var value = stringMap[key];
        maskString = maskString.replace(pattern,value);
      }
    }
    return maskString;
  }

  /**
   * Send unique id - TODO refactor
   * @returns {number}
   */
  static getLogID(){
    function s4() {
      return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
      s4() + '-' + s4() + s4() + s4();
  }

  //TODO: Verify that changing to ...loggingArguments over using compiler "arguments" works properly.
  //TODO: Verify that returning empty string instead of null is fine if there are no arguments
  /**
   * For logging string: 'Hello {0}, this is {1}',
   * Given parameters {0}-Javascript; {1}-Nodejs
   * Will return Hello Javascript, this is Nodejs.
   */
  static getLoggingString(...loggingArguments: string[]){
    if (!loggingArguments.length) {
      return '';
    }
    var pattern = loggingArguments[0];
    if (loggingArguments.length == 1) {
      return pattern;
    }
    for ( var i = 1; i < loggingArguments.length; i++) {
      var placeHolder = loggingArguments[i];
      placeHolder = CommonUtility.maskData(placeHolder);
      pattern = pattern.replace(new RegExp('\\{' + (i - 1) + '\\}', 'g'), placeHolder);
    }
    return pattern;
  }
  /**   
   * Input: String array where array is populated in pairs, being key and value
   * Output: A string that is supposed to be a log message based on the keys and values in the pairs
   * EX:[origin, DX, errorMessage, There was an error]
   * Should result in 'origin:DX,errorMessage:There was an error'
   */
  static getMaskedLogMessageFromArguments(loggingArguments: any[]) {
    let message = '';
    let index = 0;
    let jsonReplacerFunction = (key, value) => {
      if(typeof value === 'number') {
        return value.toString()
      }
      return value;
    }

    while(index != loggingArguments.length && index <= loggingArguments.length) {
      if(typeof loggingArguments[index+1] == 'undefined') {
        message+= '"' + loggingArguments[index] + '":"' + 'undefined"';
      } else if (loggingArguments[index+1] == null) {
        message+= '"' + loggingArguments[index] + '":"' + 'null"';
      } else if(typeof loggingArguments[index+1] == 'string' || loggingArguments[index+1] instanceof String) {
        message+= '"' + loggingArguments[index] + '":"' + loggingArguments[index+1] + '"';
      } else if(typeof loggingArguments[index+1] == 'object') {
        message+= '"' + loggingArguments[index] + '":' + JSON.stringify(loggingArguments[index+1], jsonReplacerFunction);
      } else if(typeof loggingArguments[index+1] == 'number' || loggingArguments[index+1] instanceof Number) {
        message+= '"' + loggingArguments[index] + '":' + loggingArguments[index+1].toString();
      } else {
        message+= '"' + loggingArguments[index] + '":"' + 'unknown-type-object"';
      }
      
      if(loggingArguments.length - 2 != index) {
        message+= '|'
      }
      index += 2;
    }
    return this.maskLogString(message);
  }

  static getBaseLogMessageArguments(level: string, className: string, methodName: string, authContext: any) : string[] {
    let logTrackingId = authContext.trackingId,
        febSecReqId = authContext.febSecReqId,
        febSecSessionId = authContext.sessionId,
        userMid = authContext.mid,
        repMid = authContext.repInfo ? authContext.repInfo.mid : '',
        repId = authContext.repInfo ? authContext.repInfo.id : '',
        productVersion = authContext.productVersion || 'DX',
        rtazLid = authContext.rtazlid;
    
        return [
        'level', level,
        'class', className,
        'method', methodName,
        'origin', 'app',
        'productVersion', productVersion,
        'logTrackingId', logTrackingId,
        'febSecReqId', febSecReqId,
        'febSecSessionId', febSecSessionId,
        'rtazlid', rtazLid,
        'repMid', repMid,
        'repId', repId,
        'userMid', userMid
        ];
  }

  static maskLogString(logMessage: string) {
    let maskString = logMessage;
    for (var key in GPILoggerClient.Logger.prototype.replaceStringMap)
    {
      var pattern = new RegExp(key,"gi");
      var value = GPILoggerClient.Logger.prototype.replaceStringMap[key];
      maskString = maskString.replace(pattern,value);
    }
		return maskString;
  }

  /**
   * Test if an object has keys and each of the keys contains value.
   * @param obj
   * @param keys
   * @returns {boolean}
   */
  static containsValues(obj: any, keys: any) {
    var contains = true;
    if(!_.isEmpty(obj) && !_.isEmpty(keys)){
      //TODO Validate that this should be any or change it
      var fields: any = [];
      if(_.isString(keys)){
        fields.push(keys);
      }else if(_.isArray(keys)){
        fields = keys;
      }
      _.forEach(fields, function(fieldName: any){
        var fieldValue = obj[fieldName];
        if(_.isEmpty(fieldValue) && !_.isNumber(fieldValue)){
          contains = false;
          return false;
        }
      });
    }else{
      contains = false;
    }
    return contains;
  }

  //Defaulting locale to united states
  static getTime(format?: any) : any{
    moment.locale('us');
    var now = new Date().getTime();
    var time: any = null;
    if(this.inArray(format, Constants.TIMER.AVAILABLE_PATTERNS)){
      time = moment(now).format(format);
    }else{
      time = now;
    }
    return time;
  }

  static getLoggingTime(){
    return this.getTime(Constants.TIMER.MILIS);
  }

  static getRouteToChannel(request: any){
    //TODO, currently we are defaulting it to A.P.P service
    return Constants.CHANNEL_APP_SVS;
  }

   static convertStringListToJSON(str: string) : any{
    var obj = {};

    if ((typeof str === 'string') && str.length > 0) {
        obj = JSON.parse('{"' + str.replace(/=/g, '":"').replace(/,/g, '","') + '"}');
    }

    return obj;
  }
}

export default CommonUtility;
