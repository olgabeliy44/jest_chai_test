//
/**
 * This servers as DAT server configurations file.
 * Which contains the common app-specific settings.
 */
import * as os from 'os';
import * as _ from 'lodash';
var path = require('path');
var rootPath = require('app-root-path').path;

export let AppConfig = {
  //Increase timeout, as some node modules responded timeout and aborted the connection
  TIMEOUT: 60000,
  DEV_MODE: process.env.DEV_MODE || 100,
  /**
   * For local testing, we have to make this server run on a port rather that 3000,
   * as it conflicts with DAT/client in our local.
   *
   * In our local, we set it to 3002.
   */
  // remove this attribute, because it has existed in config/dpcs-server-scaffold.js #Config.app.PORT
  // For local testing, we can set an environment variable: process.env.PORT, or change the default value in config/dpcs-server-scaffold.js #Config.app.PORT
  // SERVER_PORT: 3000,


  APP:{
    BASE_API_PATH: '/ftgw/digital/dx/api/',
    BASE_CONTENT_PATH: '/stgw/digital/dx/',
    APP_ID : process.env.APP_ID || 'AP118252',
    APP_NAME : process.env.APP_NAME || 'Distribution Experience API',
    POE : "NETBENEFITS",
    PORT: new Number(process.env.PORT).valueOf() || 3002,
    HOST: process.env.APP_HOST || os.hostname() + ((!_.endsWith(os.hostname(), '.cvs.com')) ? '.cvs.com' : ''),
    LOG_LEVEL: process.env.LOG_LEVEL || 'verbose',
    PRODUCT_VERSION : 'DX'
  },
  BASIC_IDENTITY: {
    APP_SVS_HOST: process.env.AP_PLATFORM_URL || 'https://ast-platformqa1.cvs.com',
    IDENTITY_PATH : process.env.IDENTITY_PATH || '/identity/2014/10/identity', // Not added in server config
  },
  OAUTH: {
    CLIENT_ID: process.env.OAUTH_CLIENT_ID || 'srvAP118252ACP',
    CLIENT_SECRET: process.env.OAUTH_CLIENT_SECRET || 'aykPSqQW4OGbV5',
    AUTHORIZATION_HOST: process.env.OAUTH_TOKEN_URL || 'https://esg-qa-oauth2-internal.cvs.com/as/resourceOwner?'
  },
  IHUB:{
    ENDPOINT: process.env.IHUB_ENDPOINT || 'https://pna-int-fin1-oma1.cvs.com',
    USERNAME: process.env.IHUB_USERNAME || '876e8a03-4a7e-48b2-82fb-36ad881a7439',
    PASSWORD: process.env.IHUB_PASSWORD || '34efd579-6580-4bb7-a269-ebabd96c3478',
    EVENT_ADVICE_PATH: '/events/advice'
  },
  HR_PORTAL: {
    HOST: process.env.HR_PORTAL_HOST || 'https://workforceservice-uat.cvs.com',
    USER_NAME: process.env.HR_PORTAL_USER_NAME || 'DISTRIBUTION_AN.1',
    PASSWORD: process.env.HR_PORTAL_PASSWORD || 'Vnu6#$R(2@bP'
  },
  TRIDION_API:{
    APP_ID : process.env.APP_ID,
    APP_NAME : process.env.APP_NAME ,
    TRIDION_HOST: process.env.TRIDION_API_HOST,
    TRIDION_REQUEST_PATH: process.env.TRIDION_API_REQUEST_PATH || "/igeapp/dat",// added in server config as in future if we change the page name
    TRIDION_URL_PATH: process.env.TRIDION_API_URL_PATH || "/ftgw/dp/content/v1" // Not added in server config
  },
  //Add logging to support log messages to a log file, so that we can future splunk it.
  LOGGING: {
    log2File: (process.env.LOG_TO_FILE === 'true') || false,
    logLevel: process.env.LOGGING_LEVEL || 'info', //{ error: 0, warn: 1, info: 2, verbose: 3, debug: 4, silly: 5 }
    logFileName: path.join(rootPath, 'system-logs/server.log')
    /* We may future change it to array
     *  like LOGGING: {
     *    log2File: true,
     *    modules:[{
     *       moduleName: 'MAUI',
     *       logLevel: 'error',
     *       logFileName: 'blahblah'
     *    },{
     *       moduleName: 'DP',
     *       logLevel: 'debug',
     *       logFileName: 'blahblah'
     *    }]
     *  }
     */
  }
};

