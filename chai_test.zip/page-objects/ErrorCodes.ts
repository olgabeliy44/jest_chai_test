
let ErrorCodes = {
    CHANNEL_APP_SVS: 'APP',
    BAD_REQUEST: '401',
    RESOURCE_NOT_FOUND_ERROR: {
      errorCode: '404',
      errorMessage: 'Resource Not Found.'
    },
    INTERNAL_SERVER_ERROR: {
      errorCode: '500',
      errorMessage: 'Internal Server Error'
    },
    APP_SVS_INTERACTION: {
      GENERIC_ERROR: {
        errorCode: 'AE001',
        errorMessage: 'A generic error occurred'
      },
      GET_IDENTITY_ERROR: {
        errorCode: 'AE005',
        errorMessage: 'Error occurred in Get Identity'
      },
      GET_REP_INFO_ERROR: {
        errorCode: 'AE030',
        errorMessage: 'Error occurred in Get Rep Info'
      },
      GET_IHUB_ERROR: {
        errorCode: 'AE021',
        errorMessage: 'Error occurred while calling iHub'
      },
      GET_AUTH_ERROR: {
        errorCode: 'AE022',
        errorMessage: 'Error occurred fetching auth context'
      },
      //This is not used in DAT-API, as we did not call it directly.
      GET_USER_IDENTIFIER_ERROR: {
        errorCode: 'AE022',
        errorMessage: 'Error occurred while retrieving User Identifier'
      },
    },
    DP_SVS_INTERACTION: {
      GENERIC_ERROR: {
        errorCode: 'DE001',
        errorMessage: 'A generic error occurred in DP service interaction'
      },
      CONTENT_API_ERROR: {
        errorCode: 'DE005',
        errorMessage: 'Error occurred in Content Api'
      },
      HR_PORTAL_API_ERROR: {
        errorCode: 'DE006',
        errorMessage: 'Error occurred in HR Portal Api'
      },
      HR_PORTAL_API_REP_ID_ERROR: {
        errorCode: 'DE007',
        errorMessage: 'Missing the required parameter \'rtazrepid\' in request headers'
      }
    },
    PRODUCT_CODE: "DAT",
    CATEGORY_CODE: "DEF",
    ENTITY_TYPE_CODE: "PLAN",
    CHANNEL: 'DAT',
    CONTEXT: 'DAT'
  };
  
  export default ErrorCodes;