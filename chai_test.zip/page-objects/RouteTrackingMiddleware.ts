'use strict';


/*
 *  This mddleware is mainly do the following jobs:
 *    1) Add context object, which contains: auth-context, request-started-time
 *    2) Add authentication context.
 *    2) apply cs203 validation rules
 *    3) Log the each of the route information for future to splunk it.
 */
var authContext = require('@gpi-auth-context');
var extend = require('extend');
// import * as ContextFetcher from '../utils/contextFetcher';
import * as express from 'express';
import { NextFunction, Response } from "express";
import { AppConfig } from './app.config';
import NewCommonResponse from './NewCommonResponse';
import CommonUtility from './CommonUtility';
import Constants from './Constants';
import ErrorCodes from './ErrorCodes';
import ErrorUtility from './error-utility';


class RouteTrackingMiddleware {

  private logger;
  private gpiOptionsHeaders;

  constructor(app: express.Application) {
    this.gpiOptionsHeaders = {
      oauthClientId: AppConfig.OAUTH.CLIENT_ID,
      oauthClientSecret: AppConfig.OAUTH.CLIENT_SECRET,
      oauthAccessTokenUri: AppConfig.OAUTH.AUTHORIZATION_HOST,
      identityResourceBaseUri: AppConfig.BASIC_IDENTITY.APP_SVS_HOST + AppConfig.BASIC_IDENTITY.IDENTITY_PATH,
      clientOpts: { 'timeout' : AppConfig.TIMEOUT },
      app: app,
      appId: AppConfig.APP.APP_ID
    }
    this.logger = app.get('Winston');

  }

  handleRouteTracking(req: any, res: Response, next: NextFunction) : void {
    let requestHeaders = req.headers;
    
    CommonUtility.getLoggingString('RouteTracking passing options to authContext - {0}', JSON.stringify(this.gpiOptionsHeaders));
    authContext.secure(requestHeaders, this.gpiOptionsHeaders).then((response: any) => {
      // clone a context object because the authContext module has freezed it.
      //TODO, we need to find out a way to cache the authentication context, otherwise, if the mid is missing,
      // we will call getUserIdentifier in the authContext for all the forthcoming requests.
      let authenticationContext = extend(true, {}, response.authenticationContext);
      // Fixing Issue: Remove reference to AuthContext.callingChannel. Always use appConfig.APP_ID.
      // appConfig.APP_ID is used for calls directly made from services modules in DAT API
      // Here is a quick fixed && less invasive solution.
      // TODO changing the node modules which used AuthContext.callingChannel and replace it with appConfig.APP_ID.
      authenticationContext.callingChannel = AppConfig.APP.APP_ID;
      authenticationContext.productVersion = AppConfig.APP.PRODUCT_VERSION;

      //refresh the req.context
      req.context = {
        authenticationContext: authenticationContext,
        startTime: CommonUtility.getLoggingTime(),
        routeToChannel: CommonUtility.getRouteToChannel(req),
      };

      if(!authenticationContext.repInfo){
        let logArgs = CommonUtility.getBaseLogMessageArguments('error', 'RouteTrackingMiddleware', 'handleRouteTracking', authenticationContext);
        logArgs.push('message', 'repInfo object missing from authenticationContext', 'fullAuthContext', authenticationContext);
        this.logger.log('error', CommonUtility.getMaskedLogMessageFromArguments(logArgs));
      }else{
        let logArgs = CommonUtility.getBaseLogMessageArguments('info', 'RouteTrackingMiddleware', 'handleRouteTracking', authenticationContext);
        logArgs.push('message', 'Rep is authenticated');
        this.logger.log('info', CommonUtility.getMaskedLogMessageFromArguments(logArgs));
      }
      next();
    }).catch((err: any) => {
      //we will use the default authcontext, with no promise to get the the context for the forthcoming error handling.
      let authenticationContext = extend(true, {}, authContext(requestHeaders).authenticationContext);

      //We have to set req.context with the SSO headers initialy, as the errorHandler.js is using it to log error messages,
      //so if the new authContext with promise fails, req.context will be undefined.
      req.context = {
        authenticationContext: authenticationContext
      };
      //Make sure there will be no "BENSUMM"-like app ids in the log.
      authenticationContext.callingChannel = AppConfig.APP.APP_ID;
      authenticationContext.productVersion = Constants.PRODUCT_VERSION;

      let logArgs = CommonUtility.getBaseLogMessageArguments('error', 'RouteTrackingMiddleware', 'handleRouteTracking', authenticationContext);
      logArgs.push('message', 'fetching auth through gpi-auth-context failed', 'err', err);
      this.logger.log('error', CommonUtility.getMaskedLogMessageFromArguments(logArgs));

      let responseProcessor = new NewCommonResponse(authenticationContext.febSecReqId);

      res.status(500).json(responseProcessor.failure({},
        ErrorCodes.APP_SVS_INTERACTION.GET_AUTH_ERROR.errorCode,
        ErrorCodes.APP_SVS_INTERACTION.GET_AUTH_ERROR.errorMessage));
    });
  };



}

export default RouteTrackingMiddleware;