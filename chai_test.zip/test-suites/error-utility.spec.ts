import 'mocha';
import CommonUtility from '../page-objects/CommonUtility';
import ErrorUtility from '../page-objects/error-utility';
import {expect} from 'chai';

describe('ErrorUtility mock function', () => {

    it("should...", () => {
        /**
         * getErrorResponse
         */
        var errorCode = '';
        var errorMessage = '';
        var logUID = CommonUtility.getLogID();
        expect(ErrorUtility.getErrorResponse(errorCode, errorMessage, logUID)).to.be.an('object');
        /**
         * buildErrorParams
         */
        const req = {
            path: '',
            context: {
                authenticationContext: ''
            }
        }; 
        var res = Object; var errorInfo = Object;
        expect(ErrorUtility.buildErrorParams(req, res, errorInfo)).to.be.an('object');
      });
});