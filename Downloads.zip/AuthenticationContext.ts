
import { AppConfig } from "../../config/app.config";

export class AuthenticationContext {
    trackingId: string;
    febSecReqId: string;
    sessionId: string;
    mid: string;
    repId: string;
    repMid: string;
    productVersion: string;
    repInfo: boolean;
    pointOfEntry: string;

    //TODO : Implement taking a request and grabbing the properties and turning it into the AuthenticationContext object
    constructor(req: any) {
        if(!req.context) {
            this.trackingId = '';
            this.febSecReqId = req.headers.fsreqid;
            this.sessionId = '';
            this.mid = req.headers.fac_mc.split(',')[6];
            this.repId = req.headers.repid;
            this.repMid = '';
            this.productVersion = '';
            this.repInfo = false;
            this.pointOfEntry = AppConfig.APP.APP_ID;
        }
         else {
            this.trackingId = req.context.authenticationContext.trackingId;
            this.febSecReqId = req.context.authenticationContext.febSecReqId;
            this.sessionId = req.context.authenticationContext.sessionId;
            this.mid = req.context.authenticationContext.febSecReqId;
            this.repId = req.context.authenticationContext.repInfo.id;
            this.repMid = req.context.authenticationContext.repInfo.mid;
            this.productVersion = req.context.authenticationContext.productVersion;
            this.repInfo = req.context.authenticationContext.repInfo ? true : false;
            this.pointOfEntry = AppConfig.APP.APP_ID;
         }
    }

    
}