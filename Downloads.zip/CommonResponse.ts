
  /**
 * This js module servers as a common model object base.
 * and all the domain level model objects should extend this,
 * so that all of them will have the common attributes.
 */
'use strict';

const extend = require('extend');

let responseStructure = {
    "status": "success",
    "code": null,
    //Represents for any services or controller errors.
    "errorCode": null,
    "errorMessage": null,
    "requestId": null
};


export class CommonResponse {
    requestId: string;
    response: any;

    constructor(requestId: string) {
        this.requestId = requestId;
        this.response = extend({}, responseStructure);
        this.response.requestId = requestId;
    }

    success(data: any): any {
        this.response = extend({}, responseStructure);
        return extend(true, this.response, data);
    }

    fail(data: any, errorCode: any, errorMessage: any): any {
        this.response = extend({}, responseStructure);
        this.response.status = "failure";
        this.response.errorCode = errorCode;
        this.response.errorMessage = errorMessage;
        return extend(true, this.response, {
            data: data
        });
    }

    failure(error: any): any {
        this.response = extend({}, responseStructure);
        this.response.status = "failure";
        this.response.errorCode = error.errorCode;
        this.response.errorMessage = error.errorMessage;
        this.response.diagnosticId = error.diagnosticID;
        this.response.timeStamp = error.timeStamp;
        return this.response;
    }

    error(httpStatusCode: any, errorMessage: any) {
    }
}