import CommonUtility from './CommonUtility';
import Constants from './constants/Constants';
const _ = require('lodash');

class ErrorUtility {
    //TODO Validation if there is another way instead of using "any" type for paramters
    static getErrorResponse(errorCode: any, errorMessage: any, logUID: any) : any{
      return {
        errorCode: errorCode,
        errorMessage: errorMessage,
        diagnosticID : logUID? logUID : CommonUtility.getLogID(),
        timeStamp : new Date()
      };
    }

    static buildErrorParams(req: any, res: any, errorInfo: any) : any{
      //We've set it in the routeRacking at the beginning, otherwise, we have to do it in a promise way,
      //which increases the complexity and may cause a bad performance or even recursive error events.
      const authenticationContext = req.context.authenticationContext;
      var errorParams = CommonUtility.getLogObjectTemplate();
      errorParams.service = 'DAT API';
      errorParams.operation = req.path;
      errorParams.authContext = authenticationContext;
      errorParams.origin =  Constants.DPCS_ORIGIN;
      errorParams.febSecReqId = authenticationContext.febSecReqId;
      errorParams.requestUri = req.path;
      errorParams.errorInfo = errorInfo;
      errorParams.request = {};
      errorParams.response = {};
      return errorParams;
    }

}

export default ErrorUtility;