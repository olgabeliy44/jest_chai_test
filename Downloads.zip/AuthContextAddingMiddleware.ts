import { AuthenticationContext } from "../models/AuthenticationContext";
import * as express from 'express';


class AuthContextAddingMiddleware {

    constructor(app: express.Application) {

    }

    addAuthContextToReq(req: any, res: any, next: any) {
        req.authContext = new AuthenticationContext(req);
        next();
    }
}

export default AuthContextAddingMiddleware;