import { AppConfig } from '../../config/app.config';
import RouteTrackingMiddleware from './RouteTrackingMiddleware';
import AuthContextAddingMiddleware from './AuthContextAddingMiddleware';
import * as express from 'express';
import DevelopmentHeadersMiddleware from './DevelopmentHeadersMiddleware';

class PreRequestMiddlewareController {

    private controllerPath = AppConfig.APP.BASE_API_PATH;
    private routeTrackingMiddleware : RouteTrackingMiddleware;
    private authContextAddingMiddleware: AuthContextAddingMiddleware
    private developmentHeaderMiddleware: DevelopmentHeadersMiddleware;
    
    public router = express.Router();
  
    constructor(app: express.Application) {
      this.routeTrackingMiddleware = new RouteTrackingMiddleware(app);
      this.authContextAddingMiddleware = new AuthContextAddingMiddleware(app);
      this.developmentHeaderMiddleware = new DevelopmentHeadersMiddleware(app);
      this.intializeRoutes();
    }
  
    intializeRoutes() : void {
      this.router.use(express.json());
      this.router.use(this.controllerPath, this.developmentHeaderMiddleware.addCustomerWebViewHeadersToRequest.bind(this.developmentHeaderMiddleware));
      this.router.use(this.controllerPath, this.authContextAddingMiddleware.addAuthContextToReq.bind(this.authContextAddingMiddleware));
      this.router.use(this.controllerPath, this.routeTrackingMiddleware.handleRouteTracking.bind(this.routeTrackingMiddleware));
    }

}

export default PreRequestMiddlewareController;


