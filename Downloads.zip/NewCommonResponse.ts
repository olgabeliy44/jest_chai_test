
const extend = require('extend');

let baseResponseStructure = {
    "status": undefined,
    "data": {},
    "errorCode": undefined,
    "errorDisplayMessage": undefined,
    "requestId": undefined
};

class NewCommonResponse {

    requestId: string;
    response: any;

    constructor(requestId: string) {
        this.requestId = requestId;
        this.response = extend({}, baseResponseStructure);
        this.response.requestId = requestId;
    }

    success(data: any): any {
        return this.createCommonResponse("success", data, "", "");
    }

    error(data: any, errorCode: any, errorDisplayMessage: any): any{
        return this.createCommonResponse("error", data, errorCode, errorDisplayMessage);
    }

    failure(data: any, errorCode: any, errorDisplayMessage: any): any{
        return this.createCommonResponse("failure", data, errorCode, errorDisplayMessage);
    }

    createCommonResponse(status: string, data: any, errorCode: string, errorDisplayMessage: string) {
        this.response.status = status;
        this.response.data = data;
        this.response.errorCode = errorCode;
        this.response.errorDisplayMessage = errorDisplayMessage;
        return this.response;
    }
}

export default NewCommonResponse;

