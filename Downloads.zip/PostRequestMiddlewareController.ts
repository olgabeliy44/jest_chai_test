import * as express from 'express';
import { AppConfig } from '../../config/app.config';
import { CommonResponse } from '../models/CommonResponse';
import CommonUtility from '../utils/CommonUtility';
import ErrorCodes from '../utils/constants/ErrorCodes';
import ErrorUtility from '../utils/ErrorUtility';

class PostRequestMiddlewareController {

    private controllerPath = AppConfig.APP.BASE_API_PATH;
    private _logger;

    public router = express.Router();
  
    constructor(app: express.Application) {
      this.logger = app.get('Winston');
      this.intializeRoutes();
    }

    public get logger() {
      return this._logger;
    }
    public set logger(value) {
      this._logger = value;
    }

    intializeRoutes() : void {
        this.router.use(this.controllerPath, this.errorNotFound.bind(this));
        this.router.use(this.controllerPath, this.internalError.bind(this));
      }

    errorNotFound(req: any, res: express.Response) : void{
        var requestId = req.headers.fsreqid,
        responseProcessor = new CommonResponse(requestId);

        var errInfo = CommonUtility.deepClone(ErrorCodes.RESOURCE_NOT_FOUND_ERROR);
        var reqParams = (req.method == 'GET' ? req.query : req.body);
        var errorParams = ErrorUtility.buildErrorParams(req, res, errInfo);
        errorParams.request = reqParams;
        var errorLogMsg = CommonUtility.showErrorLogMessage(errorParams);
        this.logger.error(errorLogMsg);

        res.status(404).json(responseProcessor.failure(ErrorUtility.getErrorResponse(errInfo.errorCode, errInfo.errorMessage, CommonUtility.getLogID())));
    }

    internalError(err: any, req: any, res: any, next: any) {
          var authenticationContext = req.context.authenticationContext,
            requestId = authenticationContext.febSecReqId;
    
          var responseProcessor = new CommonResponse(requestId);
          var errInfo;
          if(err && err.errorCode && CommonUtility.startsWith(err.errorCode, 'E')){
            errInfo = err;
          }else{
            errInfo = CommonUtility.deepClone(ErrorCodes.INTERNAL_SERVER_ERROR);
          }
          var errorParams = ErrorUtility.buildErrorParams(req, res, errInfo);
          var reqParams = (req.method == 'GET' ? req.query : req.body);
          errorParams.request = reqParams;
          if (err instanceof Error) {
            errorParams.errorResponse = {
              message: err.message,
              stack: err.stack
            }
          } else {
            errorParams.errorResponse = err;
          }
    
          var errorLogMsg = CommonUtility.showErrorLogMessage(errorParams);
            this.logger.error(errorLogMsg);
    
          res.status(500).json(responseProcessor.failure(ErrorUtility.getErrorResponse(errInfo.errorCode, errInfo.errorMessage, CommonUtility.getLogID())));
        }

}

export default PostRequestMiddlewareController;